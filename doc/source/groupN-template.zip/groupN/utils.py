#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# This would be a good place for utility functions.

def utility():
    pass

